/* 
 * File:   USART.h
 * Author: Gaby
 *
 * Created on 2 de marzo de 2021, 09:04 PM
 */

#ifndef USART_H
#define	USART_H

void CONFIG_USART (void);

uint8_t ASCII(uint8_t aconvertir);

#endif	/* USART_H */

