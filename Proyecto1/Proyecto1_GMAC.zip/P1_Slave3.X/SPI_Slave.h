/* 
 * File:   SPI_Slave.h
 * Author: Gaby
 *
 * Created on 12 de febrero de 2021, 11:30 AM
 */

#ifndef SPI_SLAVE_H
#define	SPI_SLAVE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* SPI_SLAVE_H */

