/* 
 * File:   USART.h
 * Author: Gaby
 *
 * Created on 16 de febrero de 2021, 08:07 PM
 */

#ifndef USART_H
#define	USART_H

void CONFIG_USART (void);

uint8_t ASCII(uint8_t aconvertir);

#endif	/* USART_H */

